export const servers = [
  { id: "streamwish", name: "Streamwish" },
  { id: "gogocdn", name: "Gogo server" },
  { id: "vidstreaming", name: "Vidstreaming" },
  { id: "mp4upload", name: "Mp4Upload" },
];
